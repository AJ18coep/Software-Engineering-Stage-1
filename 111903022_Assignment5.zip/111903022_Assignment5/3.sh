if [ $# -eq 0 ]
then 
	echo "No Argument Passed"
	exit 1
fi
file=$1
if [ -w $file ]
then
	echo "The File Has Write Permission"
else
	echo "The File Does Not Have Write Permission"
fi
if [ -x $file ]
then
	echo "The File Has Executable Permission"
else
	echo "The File Does Not Have Executable Permission"
fi
