for d in *
	do
		echo $d
	done

