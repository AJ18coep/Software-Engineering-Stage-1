echo "1. Finding Odd/Even Number"
echo "2. Finding Largest Of Three Numbers"
echo "Enter Your Choice"
read choice
if [ $choice -eq 1 ]
then	
        echo "Enter The Number"
	read number
	result=$(( $number % 2 ))
	if [ $result -eq 0 ]
	then
		echo "The Number Is Even"
	else
		echo "The Number Is Odd"
	fi
elif [ $choice -eq 2 ]
then
	echo "Enter The Three Numbers"
	read num1 num2 num3
	result=$num1
	if [ $num2 -lt $result ]
	then
		result=$num2
	fi
	if [ $num3 -lt $result ]
	then
		result=$num3
	fi
	echo Smallest Number is $result
else
	echo "Enter Valid Option"
	exit 1

fi
