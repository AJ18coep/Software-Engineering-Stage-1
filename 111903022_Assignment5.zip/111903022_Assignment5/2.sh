if [ "$#" = 0 ]
then
	echo "No Argument Passed"
	exit 1
fi
if [ "$#" = 0 ]
then
	echo "Only One Argument Passed"
	exit 1
else
	if [ $1 -gt $2 ]
	then
		echo $1 Is Largest
	else
		echo $2 Is Largest
	fi
fi

