day="$(date +'%A')"
if [ "$day" = "Monday" ]
then
	echo "Happy Howl Day"
elif [ "$day" = "Tuesday" ]
then
	echo "Happy Day Two"
elif [ "$day" = "Wednesday" ]
then
	echo "Happy Hump Day"
elif [ "$day" = "Thursday" ]
then
	echo "Happy Thirst Day"
elif [ "$day" = "Friday" ]
then
	echo "Happy Fried Day"
elif [ "$day" = "Saturday" ]
then
	echo "Happy Sit 'Er Down Day"
else
	echo "Happy Fun Day"
fi

